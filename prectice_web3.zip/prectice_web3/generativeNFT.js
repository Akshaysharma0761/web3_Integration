const Web3=require('web3');
 let web3=new Web3(new Web3.providers.HttpProvider("https://eth-ropsten.alchemyapi.io/v2/G09XWM6tE3GvWyYrpBGMFhWP2rCOPktd"))

 const abi=[
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "owner",
				"type": "address"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "approved",
				"type": "address"
			},
			{
				"indexed": true,
				"internalType": "uint256",
				"name": "tokenId",
				"type": "uint256"
			}
		],
		"name": "Approval",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "owner",
				"type": "address"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "operator",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "bool",
				"name": "approved",
				"type": "bool"
			}
		],
		"name": "ApprovalForAll",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "string",
				"name": "baseURI",
				"type": "string"
			}
		],
		"name": "BaseURIChanged",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "minter",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "amountOfNFTs",
				"type": "uint256"
			}
		],
		"name": "Minted",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "previousOwner",
				"type": "address"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "newOwner",
				"type": "address"
			}
		],
		"name": "OwnershipTransferred",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "from",
				"type": "address"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "to",
				"type": "address"
			},
			{
				"indexed": true,
				"internalType": "uint256",
				"name": "tokenId",
				"type": "uint256"
			}
		],
		"name": "Transfer",
		"type": "event"
	},
	{
		"inputs": [],
		"name": "MAX_NFT_SUPPLY",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "MAX_NFT_WALLET",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "NFT_PRICE",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "to",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "tokenId",
				"type": "uint256"
			}
		],
		"name": "approve",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "owner",
				"type": "address"
			}
		],
		"name": "balanceOf",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "baseTokenURI",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "tokenId",
				"type": "uint256"
			}
		],
		"name": "getApproved",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "owner",
				"type": "address"
			},
			{
				"internalType": "address",
				"name": "operator",
				"type": "address"
			}
		],
		"name": "isApprovedForAll",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "amountOfNFTs",
				"type": "uint256"
			}
		],
		"name": "mintNFT",
		"outputs": [],
		"stateMutability": "payable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "name",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "owner",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "tokenId",
				"type": "uint256"
			}
		],
		"name": "ownerOf",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "renounceOwnership",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "from",
				"type": "address"
			},
			{
				"internalType": "address",
				"name": "to",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "tokenId",
				"type": "uint256"
			}
		],
		"name": "safeTransferFrom",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "from",
				"type": "address"
			},
			{
				"internalType": "address",
				"name": "to",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "tokenId",
				"type": "uint256"
			},
			{
				"internalType": "bytes",
				"name": "_data",
				"type": "bytes"
			}
		],
		"name": "safeTransferFrom",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "operator",
				"type": "address"
			},
			{
				"internalType": "bool",
				"name": "approved",
				"type": "bool"
			}
		],
		"name": "setApprovalForAll",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "baseURI",
				"type": "string"
			}
		],
		"name": "setBaseURI",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_amount",
				"type": "uint256"
			}
		],
		"name": "setMAX_NFT_WALLET",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_amount",
				"type": "uint256"
			}
		],
		"name": "setNFT_PRICE",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "bytes4",
				"name": "interfaceId",
				"type": "bytes4"
			}
		],
		"name": "supportsInterface",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "symbol",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "index",
				"type": "uint256"
			}
		],
		"name": "tokenByIndex",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "owner",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "index",
				"type": "uint256"
			}
		],
		"name": "tokenOfOwnerByIndex",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "tokenId",
				"type": "uint256"
			}
		],
		"name": "tokenURI",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "totalSupply",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "from",
				"type": "address"
			},
			{
				"internalType": "address",
				"name": "to",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "tokenId",
				"type": "uint256"
			}
		],
		"name": "transferFrom",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "newOwner",
				"type": "address"
			}
		],
		"name": "transferOwnership",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "withdrawAll",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	}
]

const contractaddress="0x856a2b84c89B47382F56FB8D59aC35a1F01661b3";

const contract= new web3.eth.Contract(abi,contractaddress)

const mintNFT=async()=>{
try {
    var count =await web3.eth.getTransactionCount('0xB42c84e862705965c001F76E7AC78a841c668095');
    console.log("count========>",count);

    const data =await contract.methods.mintNFT('2').encodeABI()

    console.log("hello=======>",await web3.eth.getGasPrice());

    var rawTransaction={
        "to":contractaddress,
        "nonce":web3.utils.toHex(count),
        "gasPrice":web3.utils.toHex('17000000640'),
        "gasLimit":web3.utils.toHex('3100000'),
        "data":data,
        "value":web3.utils.toWei("0.08")
    };

    console.log('helloooo====>');
    const signedTx=await web3.eth.accounts.signTransaction(rawTransaction,"8e73e4d60e1a83e66a00758e2f4ed21aed960b33b090a3e874eafbf61e252583")
    console.log('hellooo===>',signedTx);

    const receipt=await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
    console.log(`Transaction hash: ${receipt.transactionHash}`);
    


} catch (error) {
    console.log("mintNFT Error======>",error)
}
}

const GetFunction=async()=>{
	let MAX_NFT_SUPPLY=await contract.methods.MAX_NFT_SUPPLY().call();
    console.log("MAX_NFT_SUPPLY=======>",MAX_NFT_SUPPLY.toString());

	let MAX_NFT_WALLET=await contract.methods.MAX_NFT_WALLET().call();
    console.log("MAX_NFT_WALLET=======>",MAX_NFT_WALLET.toString());

	let NFT_PRICE=await contract.methods.NFT_PRICE().call();
    console.log("NFT_PRICE=======>",NFT_PRICE.toString());

	let owner=await contract.methods.owner().call();
    console.log("owner=======>",owner.toString());

	let name=await contract.methods.name().call();
    console.log("name=======>",name.toString());

	let symbol=await contract.methods.symbol().call();
    console.log("symbol=======>",symbol.toString());

	let totalSupply=await contract.methods.totalSupply().call();
    console.log("totalSupply=======>",totalSupply.toString());
}
const balanceOf=async()=>{
	let balanceOf=await contract.methods.balanceOf("0xB42c84e862705965c001F76E7AC78a841c668095").call();
	console.log("balanceOf=======>",balanceOf);
}
const setMAX_NFT_WALLET=async()=>{
	try {
		var count =await web3.eth.getTransactionCount('0xB42c84e862705965c001F76E7AC78a841c668095');
		console.log("count========>",count);
	
		const data =await contract.methods.setMAX_NFT_WALLET('2').encodeABI()
	
		console.log("hello=======>",await web3.eth.getGasPrice());
	
		var rawTransaction={
			"to":contractaddress,
			"nonce":web3.utils.toHex(count),
			"gasPrice":web3.utils.toHex('17000000640'),
			"gasLimit":web3.utils.toHex('3100000'),
			"data":data,
			
		};
	
		console.log('helloooo====>');
		const signedTx=await web3.eth.accounts.signTransaction(rawTransaction,"8e73e4d60e1a83e66a00758e2f4ed21aed960b33b090a3e874eafbf61e252583")
		console.log('hellooo===>',signedTx);
	
		const receipt=await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
		console.log(`Transaction hash: ${receipt.transactionHash}`);
		
	
	
	} catch (error) {
		console.log("Wallet Error======>",error)
	}
}

const setNFT_PRICE=async()=>{
	try {
		var count =await web3.eth.getTransactionCount('0xB42c84e862705965c001F76E7AC78a841c668095');
		console.log("count========>",count);
	
		const data =await contract.methods.setNFT_PRICE('').encodeABI()
	
		console.log("hello=======>",await web3.eth.getGasPrice());
	
		var rawTransaction={
			"to":contractaddress,
			"nonce":web3.utils.toHex(count),
			"gasPrice":web3.utils.toHex('17000000640'),
			"gasLimit":web3.utils.toHex('3100000'),
			"data":data,
			
		};
	
		console.log('helloooo====>');
		const signedTx=await web3.eth.accounts.signTransaction(rawTransaction,"8e73e4d60e1a83e66a00758e2f4ed21aed960b33b090a3e874eafbf61e252583")
		console.log('hellooo===>',signedTx);
	
		const receipt=await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
		console.log(`Transaction hash: ${receipt.transactionHash}`);
		
	
	
	} catch (error) {
		console.log("price Error======>",error)
	}
}

const transferOwnership=async()=>{
	try {
		var count =await web3.eth.getTransactionCount('0xB42c84e862705965c001F76E7AC78a841c668095');
		console.log("count========>",count);
	
		const data =await contract.methods.transferOwnership('0x970181174956405D689aBBcBF16270b39938d1B9').encodeABI()
	
		console.log("hello=======>",await web3.eth.getGasPrice());
	
		var rawTransaction={
			"to":contractaddress,
			"nonce":web3.utils.toHex(count),
			"gasPrice":web3.utils.toHex('17000000640'),
			"gasLimit":web3.utils.toHex('3100000'),
			"data":data,
			
		};
	
		console.log('helloooo====>');
		const signedTx=await web3.eth.accounts.signTransaction(rawTransaction,"8e73e4d60e1a83e66a00758e2f4ed21aed960b33b090a3e874eafbf61e252583")
		console.log('hellooo===>',signedTx);
	
		const receipt=await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
		console.log(`Transaction hash: ${receipt.transactionHash}`);
		
	
	
	} catch (error) {
		console.log("price Error======>",error)
	}
}

// balanceOf();
// GetFunction();
// mintNFT();
// setMAX_NFT_WALLET();
// setNFT_PRICE();
// transferOwnership();