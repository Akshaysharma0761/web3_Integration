const Web3=require('web3');
let web3= new Web3(new Web3.providers.HttpProvider('https://eth-ropsten.alchemyapi.io/v2/W99lDlEfTPNihVPIJHx5PiCBiDQYin_9'))

const abi=[
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_acceptedToken",
				"type": "address"
			}
		],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "bytes32",
				"name": "id",
				"type": "bytes32"
			}
		],
		"name": "BidAccepted",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "bytes32",
				"name": "id",
				"type": "bytes32"
			}
		],
		"name": "BidCancelled",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "bytes32",
				"name": "id",
				"type": "bytes32"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "nftAddress",
				"type": "address"
			},
			{
				"indexed": true,
				"internalType": "uint256",
				"name": "assetId",
				"type": "uint256"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "bidder",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "priceInWei",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "expiresAt",
				"type": "uint256"
			}
		],
		"name": "BidCreated",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "cutPerMillion",
				"type": "uint256"
			}
		],
		"name": "ChangedFeePerMillion",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "bytes32",
				"name": "id",
				"type": "bytes32"
			}
		],
		"name": "OrderCancelled",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "bytes32",
				"name": "id",
				"type": "bytes32"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "seller",
				"type": "address"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "nftAddress",
				"type": "address"
			},
			{
				"indexed": true,
				"internalType": "uint256",
				"name": "assetId",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "priceInWei",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "expiresAt",
				"type": "uint256"
			}
		],
		"name": "OrderCreated",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "bytes32",
				"name": "id",
				"type": "bytes32"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "buyer",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "priceInWei",
				"type": "uint256"
			}
		],
		"name": "OrderSuccessful",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "bytes32",
				"name": "id",
				"type": "bytes32"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "priceInWei",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "expiresAt",
				"type": "uint256"
			}
		],
		"name": "OrderUpdated",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "previousOwner",
				"type": "address"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "newOwner",
				"type": "address"
			}
		],
		"name": "OwnershipTransferred",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "account",
				"type": "address"
			}
		],
		"name": "Paused",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "account",
				"type": "address"
			}
		],
		"name": "Unpaused",
		"type": "event"
	},
	{
		"inputs": [],
		"name": "_INTERFACE_ID_ERC721",
		"outputs": [
			{
				"internalType": "bytes4",
				"name": "",
				"type": "bytes4"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_nftAddress",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "_assetId",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "_priceInWei",
				"type": "uint256"
			}
		],
		"name": "acceptBid",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "acceptedToken",
		"outputs": [
			{
				"internalType": "contract IERC20",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "bidByOrderId",
		"outputs": [
			{
				"internalType": "bytes32",
				"name": "id",
				"type": "bytes32"
			},
			{
				"internalType": "address",
				"name": "bidder",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "price",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "expiresAt",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_nftAddress",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "_assetId",
				"type": "uint256"
			}
		],
		"name": "cancelBid",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_nftAddress",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "_assetId",
				"type": "uint256"
			}
		],
		"name": "cancelOrder",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_nftAddress",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "_assetId",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "_priceInWei",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "_expiresAt",
				"type": "uint256"
			}
		],
		"name": "createOrder",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "cutPerMillion",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "maxCutPerMillion",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			},
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			},
			{
				"internalType": "bytes",
				"name": "",
				"type": "bytes"
			}
		],
		"name": "onERC721Received",
		"outputs": [
			{
				"internalType": "bytes4",
				"name": "",
				"type": "bytes4"
			}
		],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "orderByAssetId",
		"outputs": [
			{
				"internalType": "bytes32",
				"name": "id",
				"type": "bytes32"
			},
			{
				"internalType": "address",
				"name": "seller",
				"type": "address"
			},
			{
				"internalType": "address",
				"name": "nftAddress",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "price",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "expiresAt",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "owner",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "paused",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "renounceOwnership",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_nftAddress",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "_assetId",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "_priceInWei",
				"type": "uint256"
			}
		],
		"name": "safeExecuteOrder",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_nftAddress",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "_assetId",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "_priceInWei",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "_expiresAt",
				"type": "uint256"
			}
		],
		"name": "safePlaceBid",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_cutPerMillion",
				"type": "uint256"
			}
		],
		"name": "setOwnerCutPerMillion",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "bool",
				"name": "_setPaused",
				"type": "bool"
			}
		],
		"name": "setPaused",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "newOwner",
				"type": "address"
			}
		],
		"name": "transferOwnership",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_nftAddress",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "_assetId",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "_priceInWei",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "_expiresAt",
				"type": "uint256"
			}
		],
		"name": "updateOrder",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	}
]

const contractaddress="0xE5BAA6ecdF259CDa0222b6390e2438D3E5C965cb";

const contract =new web3.eth.Contract(abi,contractaddress)

const GetFunction=async()=>{
try {
    let paused=await contract.methods.paused().call();
    console.log("paused=======>",paused.toString());

    let owner=await contract.methods.owner().call();
    console.log("owner=======>",owner.toString());

    let acceptedToken=await contract.methods.acceptedToken().call();
    console.log("acceptedToken=======>",acceptedToken.toString());

    let maxCutPerMillion=await contract.methods.maxCutPerMillion().call();
    console.log("maxCutPerMillion=======>",maxCutPerMillion.toString());

    let cutPerMillion=await contract.methods.cutPerMillion().call();
    console.log("cutPerMillion=======>",cutPerMillion.toString());

    
    
} catch (error) {
    console.log("error===========>",error)
}
}

const orderByAssetId=async()=>{
	let orderByAssetId=await contract.methods.orderByAssetId("0xD422300CEC7Ee10Fa26f9D5Ce317215A4C190d06","2").call();
    console.log("orderByAssetId=======>",orderByAssetId);
}

const bidByOrderId=async()=>{
	let bidByOrderId=await contract.methods.bidByOrderId("0xD422300CEC7Ee10Fa26f9D5Ce317215A4C190d06","2").call();
    console.log("bidByOrderId=======>",bidByOrderId);

}

const createOrder=async()=>{
    try {
        var count = await web3.eth.getTransactionCount('0xB42c84e862705965c001F76E7AC78a841c668095');
		console.log("count==123===>",count);
        // const data = await contract.methods.withdraw().encodeABI()
		const data= await contract.methods.createOrder("0xD422300CEC7Ee10Fa26f9D5Ce317215A4C190d06","2","1000000000000000000","1644237857").encodeABI()
        
        console.log('helloooo===>',await web3.eth.getGasPrice());
        var rawTransaction = {
            "to": contractaddress,
            "nonce": web3.utils.toHex(count),
            "gasPrice": web3.utils.toHex('17000000640'),
            "gasLimit": web3.utils.toHex('3100000'),
            "data": data,
			
        };


        console.log('helloooo===>');

        const signedTx = await web3.eth.accounts.signTransaction(rawTransaction, '8e73e4d60e1a83e66a00758e2f4ed21aed960b33b090a3e874eafbf61e252583')
        console.log('helloooo===>', signedTx);

        const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
        console.log(`Transaction hash: ${receipt.transactionHash}`);

    } catch (error) {
        console.log("createOrder error========>", error);
    }
	
}

const updateOrder=async()=>{
	try {
		var count = await web3.eth.getTransactionCount('0xB42c84e862705965c001F76E7AC78a841c668095');
		console.log("count==123===>",count);
        // const data = await contract.methods.withdraw().encodeABI()
		const data= await contract.methods.updateOrder("0xD422300CEC7Ee10Fa26f9D5Ce317215A4C190d06","2","101100000000000000000","1644237857").encodeABI()
        
        console.log('helloooo===>',await web3.eth.getGasPrice());
        var rawTransaction = {
            "to": contractaddress,
            "nonce": web3.utils.toHex(count),
            "gasPrice": web3.utils.toHex('17000000640'),
            "gasLimit": web3.utils.toHex('3100000'),
            "data": data,
			
        };


        console.log('helloooo===>');

        const signedTx = await web3.eth.accounts.signTransaction(rawTransaction, '8e73e4d60e1a83e66a00758e2f4ed21aed960b33b090a3e874eafbf61e252583')
        console.log('helloooo===>', signedTx);

        const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
        console.log(`Transaction hash: ${receipt.transactionHash}`);
	} catch (error) {
		console.log("updateOrder error========>", error);
	}
}
const acceptBid=async()=>{
	try {
		var count = await web3.eth.getTransactionCount('0xB42c84e862705965c001F76E7AC78a841c668095');
		console.log("count==123===>",count);
        // const data = await contract.methods.withdraw().encodeABI()
		const data= await contract.methods.acceptBid("0xD422300CEC7Ee10Fa26f9D5Ce317215A4C190d06","2","50000000000").encodeABI()
        
        console.log('helloooo===>',await web3.eth.getGasPrice());
        var rawTransaction = {
            "to": contractaddress,
            "nonce": web3.utils.toHex(count),
            "gasPrice": web3.utils.toHex('17000000640'),
            "gasLimit": web3.utils.toHex('3100000'),
            "data": data,
			
        };


        console.log('helloooo===>');

        const signedTx = await web3.eth.accounts.signTransaction(rawTransaction, '8e73e4d60e1a83e66a00758e2f4ed21aed960b33b090a3e874eafbf61e252583')
        console.log('helloooo===>', signedTx);

        const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
        console.log(`Transaction hash: ${receipt.transactionHash}`);
	} catch (error) {
		console.log("acceptBid error======>",error);
	}
}

const safePlaceBid=async()=>{
	try {
		var count = await web3.eth.getTransactionCount('0xB42c84e862705965c001F76E7AC78a841c668095');
		console.log("count==123===>",count);
        // const data = await contract.methods.withdraw().encodeABI()
		const data= await contract.methods.safePlaceBid("0xD422300CEC7Ee10Fa26f9D5Ce317215A4C190d06","2","50000000000","1644237857").encodeABI()
        
        console.log('helloooo===>',await web3.eth.getGasPrice());
        var rawTransaction = {
            "to": contractaddress,
            "nonce": web3.utils.toHex(count),
            "gasPrice": web3.utils.toHex('17000000640'),
            "gasLimit": web3.utils.toHex('3100000'),
            "data": data,
			
        };


        console.log('helloooo===>');

        const signedTx = await web3.eth.accounts.signTransaction(rawTransaction, '8e73e4d60e1a83e66a00758e2f4ed21aed960b33b090a3e874eafbf61e252583')
        console.log('helloooo===>', signedTx);

        const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
        console.log(`Transaction hash: ${receipt.transactionHash}`);
	} catch (error) {
		console.log("safePlaceBid error======>",error);
	}
}

const cancelBid=async()=>{
	try {
		var count = await web3.eth.getTransactionCount('0xB42c84e862705965c001F76E7AC78a841c668095');
		console.log("count==123===>",count);
        // const data = await contract.methods.withdraw().encodeABI()
		const data= await contract.methods.cancelBid("0x101134cC2b3F4aEb3a99aFC015C9E23801c6ba64","1").encodeABI()
        
        console.log('helloooo===>',await web3.eth.getGasPrice());
        var rawTransaction = {
            "to": contractaddress,
            "nonce": web3.utils.toHex(count),
            "gasPrice": web3.utils.toHex('17000000640'),
            "gasLimit": web3.utils.toHex('3100000'),
            "data": data,
			
        };


        console.log('helloooo===>');

        const signedTx = await web3.eth.accounts.signTransaction(rawTransaction, '8e73e4d60e1a83e66a00758e2f4ed21aed960b33b090a3e874eafbf61e252583')
        console.log('helloooo===>', signedTx);

        const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
        console.log(`Transaction hash: ${receipt.transactionHash}`);
	} catch (error) {
		console.log("acceptBid error======>",error);
	}
}
const cancelOrder=async()=>{
	try {
        var count = await web3.eth.getTransactionCount('0xB42c84e862705965c001F76E7AC78a841c668095');
		console.log("count==123===>",count);
        // const data = await contract.methods.withdraw().encodeABI()
		const data= await contract.methods.cancelOrder("0x101134cC2b3F4aEb3a99aFC015C9E23801c6ba64","1").encodeABI()
        
        console.log('helloooo===>',await web3.eth.getGasPrice());
        var rawTransaction = {
            "to": contractaddress,
            "nonce": web3.utils.toHex(count),
            "gasPrice": web3.utils.toHex('17000000640'),
            "gasLimit": web3.utils.toHex('3100000'),
            "data": data,
			
        };


        console.log('helloooo===>');

        const signedTx = await web3.eth.accounts.signTransaction(rawTransaction, '8e73e4d60e1a83e66a00758e2f4ed21aed960b33b090a3e874eafbf61e252583')
        console.log('helloooo===>', signedTx);

        const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
        console.log(`Transaction hash: ${receipt.transactionHash}`);

    } catch (error) {
        console.log("createOrder error========>", error);
    }
}



// createOrder();
// bidByOrderId();
// orderByAssetId();
// GetFunction();
// updateOrder();
// acceptBid();
// safePlaceBid();
// cancelBid();
// cancelOrder();